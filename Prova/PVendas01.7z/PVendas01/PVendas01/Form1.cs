﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PVendas01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            String Saida = "";
            double[,] Mês = new double[3, 4];
            String Auxiliar = "";

            for (int i = 0; i < 3; i++) 
            {
                for (int j = 0; j < 4; j++) 
                {
                    Auxiliar = Interaction.InputBox($"Digite o total do mês {i + 1} da semana {j + 1}: ", "entrada de dados");


                    Saida += $"Total do mês: {i + 1} : da semana.{j + 1}:\n";
                }
            }

            MessageBox.Show(Saida);
        }
    }
}
