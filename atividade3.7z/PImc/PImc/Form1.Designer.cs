﻿namespace PImc
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.TxtAltura = new System.Windows.Forms.MaskedTextBox();
            this.TxtPesoAtual = new System.Windows.Forms.MaskedTextBox();
            this.LblPesoAtual = new System.Windows.Forms.Label();
            this.LblAltura = new System.Windows.Forms.Label();
            this.LblIMC = new System.Windows.Forms.Label();
            this.TxtIMC = new System.Windows.Forms.MaskedTextBox();
            this.BtnCalcular = new System.Windows.Forms.Button();
            this.BtnLimpar = new System.Windows.Forms.Button();
            this.BtnSair = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // TxtAltura
            // 
            this.TxtAltura.Location = new System.Drawing.Point(328, 117);
            this.TxtAltura.Mask = "0,00";
            this.TxtAltura.Name = "TxtAltura";
            this.TxtAltura.Size = new System.Drawing.Size(210, 26);
            this.TxtAltura.TabIndex = 0;
            // 
            // TxtPesoAtual
            // 
            this.TxtPesoAtual.Location = new System.Drawing.Point(328, 85);
            this.TxtPesoAtual.Mask = "900,00";
            this.TxtPesoAtual.Name = "TxtPesoAtual";
            this.TxtPesoAtual.Size = new System.Drawing.Size(210, 26);
            this.TxtPesoAtual.TabIndex = 1;
            // 
            // LblPesoAtual
            // 
            this.LblPesoAtual.AutoSize = true;
            this.LblPesoAtual.Location = new System.Drawing.Point(215, 85);
            this.LblPesoAtual.Name = "LblPesoAtual";
            this.LblPesoAtual.Size = new System.Drawing.Size(86, 20);
            this.LblPesoAtual.TabIndex = 2;
            this.LblPesoAtual.Text = "Peso Atual";
            // 
            // LblAltura
            // 
            this.LblAltura.AutoSize = true;
            this.LblAltura.Location = new System.Drawing.Point(215, 117);
            this.LblAltura.Name = "LblAltura";
            this.LblAltura.Size = new System.Drawing.Size(51, 20);
            this.LblAltura.TabIndex = 3;
            this.LblAltura.Text = "Altura";
            // 
            // LblIMC
            // 
            this.LblIMC.AutoSize = true;
            this.LblIMC.Location = new System.Drawing.Point(215, 149);
            this.LblIMC.Name = "LblIMC";
            this.LblIMC.Size = new System.Drawing.Size(38, 20);
            this.LblIMC.TabIndex = 4;
            this.LblIMC.Text = "IMC";
            // 
            // TxtIMC
            // 
            this.TxtIMC.Location = new System.Drawing.Point(328, 149);
            this.TxtIMC.Name = "TxtIMC";
            this.TxtIMC.Size = new System.Drawing.Size(210, 26);
            this.TxtIMC.TabIndex = 5;
            // 
            // BtnCalcular
            // 
            this.BtnCalcular.Location = new System.Drawing.Point(219, 292);
            this.BtnCalcular.Name = "BtnCalcular";
            this.BtnCalcular.Size = new System.Drawing.Size(93, 42);
            this.BtnCalcular.TabIndex = 6;
            this.BtnCalcular.Text = "Calcular";
            this.BtnCalcular.UseVisualStyleBackColor = true;
            this.BtnCalcular.Click += new System.EventHandler(this.BtnCalcular_Click);
            // 
            // BtnLimpar
            // 
            this.BtnLimpar.Location = new System.Drawing.Point(328, 292);
            this.BtnLimpar.Name = "BtnLimpar";
            this.BtnLimpar.Size = new System.Drawing.Size(94, 42);
            this.BtnLimpar.TabIndex = 7;
            this.BtnLimpar.Text = "Limpar";
            this.BtnLimpar.UseVisualStyleBackColor = true;
            this.BtnLimpar.Click += new System.EventHandler(this.BtnLimpar_Click);
            // 
            // BtnSair
            // 
            this.BtnSair.Location = new System.Drawing.Point(444, 292);
            this.BtnSair.Name = "BtnSair";
            this.BtnSair.Size = new System.Drawing.Size(94, 42);
            this.BtnSair.TabIndex = 8;
            this.BtnSair.Text = "Sair";
            this.BtnSair.UseVisualStyleBackColor = true;
            this.BtnSair.Click += new System.EventHandler(this.BtnSair_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.BtnSair);
            this.Controls.Add(this.BtnLimpar);
            this.Controls.Add(this.BtnCalcular);
            this.Controls.Add(this.TxtIMC);
            this.Controls.Add(this.LblIMC);
            this.Controls.Add(this.LblAltura);
            this.Controls.Add(this.LblPesoAtual);
            this.Controls.Add(this.TxtPesoAtual);
            this.Controls.Add(this.TxtAltura);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MaskedTextBox TxtAltura;
        private System.Windows.Forms.MaskedTextBox TxtPesoAtual;
        private System.Windows.Forms.Label LblPesoAtual;
        private System.Windows.Forms.Label LblAltura;
        private System.Windows.Forms.Label LblIMC;
        private System.Windows.Forms.MaskedTextBox TxtIMC;
        private System.Windows.Forms.Button BtnCalcular;
        private System.Windows.Forms.Button BtnLimpar;
        private System.Windows.Forms.Button BtnSair;
    }
}

