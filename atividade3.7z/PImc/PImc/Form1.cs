﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PImc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnCalcular_Click(object sender, EventArgs e)
        {
            if(!double.TryParse(TxtPesoAtual.Text, out double peso) || (peso <= 0))
            {
                MessageBox.Show("Peso Inválido");
                TxtPesoAtual.Focus();
            }
            else if (!double.TryParse(TxtAltura.Text, out double altura))
            {
                MessageBox.Show("Altura Inválida");
                TxtAltura.Focus();
            }
            else
            {
                double imc = peso / (altura * altura);

                imc = Math.Round(imc, 1);
                TxtIMC.Text = imc.ToString();

                string classificacao = "";

                if (imc < 18.5)
                {
                    classificacao = "Magreza (Grau 0)";
                }
                else if(imc <= 24.9)
                {
                    classificacao = "Normal (grau 0)";
                }
                else if(imc <= 29.9)
                {
                    classificacao = "Sobrepeso (Grau 1)";
                }
                else if(imc <= 39.9)
                {
                    classificacao = "Obesidade (grau 2)"; 
                }
                else
                {
                    classificacao = "Obesidade grave (grau 3)";
                }

                MessageBox.Show($"Seu IMC é: {imc}\nClassificação: {classificacao}", "Resultado e classificação do IMC");

            }
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            TxtPesoAtual.Text = string.Empty;
            TxtAltura.Text = string.Empty;
            TxtIMC.Text = string.Empty;

            TxtPesoAtual.Focus();
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
